class Cell:
    pass